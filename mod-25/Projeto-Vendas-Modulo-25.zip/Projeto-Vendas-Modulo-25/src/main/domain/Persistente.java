package main.domain;

public interface Persistente {
}
