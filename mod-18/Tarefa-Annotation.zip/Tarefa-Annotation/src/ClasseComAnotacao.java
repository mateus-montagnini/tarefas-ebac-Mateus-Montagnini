import java.security.PublicKey;

@Tabela(value = "Produtos")
public class ClasseComAnotacao {
    @Tabela(value = "Produtos")
    public ClasseComAnotacao() {

    }
}
