import java.lang.annotation.Documented;

@Documented
public @interface Tabela {
    String value();
}
